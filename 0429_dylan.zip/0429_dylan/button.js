$(document).ready(function() {

   $("#purpose_filter").click(function(event) {
      purpose = $(this).attr("purpose_value");
      console.log(purpose);
      updateBar();
   });


   $("#mode_filter").click(function(event) {
      mode = $(this).attr("mode_value");
      console.log(mode);
      updateBar(mode, purpose);
   });
});
