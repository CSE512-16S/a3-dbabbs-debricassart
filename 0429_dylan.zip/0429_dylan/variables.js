var purpose = Array.apply(0, Array(4)).map(function (x, y) { return y + 1; });
var mode = Array.apply(0, Array(5)).map(function (x, y) { return y + 1; });
var hour = 'all';
