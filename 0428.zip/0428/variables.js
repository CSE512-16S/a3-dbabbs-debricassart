var mode = Array.apply(0, Array(20)).map(function (x, y) { return y + 1; });;
var purpose = 'all';
var hour = 'all';